#1029-3.py
#radio button
#padding margin

from tkinter import *

def P20191029_3() :

    def event_hand() :
        
        if var.get() == 1 :
            l2.configure(image=photo129)
            print(var.get())
        elif var.get() == 2 :
            l2.configure(image=photo229)
            print(var.get())
        else :
            l2.configure(image=photo329)
            print(var.get())
            
    window = Tk()
    window.geometry("400x400")
    window.title("pet select")
    window.resizable(width=FALSE,height=FALSE)

    w3=Canvas(window, width=400, height=400)
    w3.pack()

    l1_29 = Label(w3,text="like animal?",fg="blue", font=("굴림",20))

    var = IntVar()
    rb1 = Radiobutton(w3,text="강아지",variable=var, value=1)
    rb2 = Radiobutton(w3,text="고양이",variable=var, value=1)
    rb3 = Radiobutton(w3,text="토끼",variable=var, value=1)
    btnok = Button(w3,text="사진보기",command=event_hand)

    photo129 = PhotoImage(master=w3,file="./img/dog3.gif")
    photo229 = PhotoImage(master=w3,file="./img/cat2.gif")
    photo329 = PhotoImage(master=w3,file="./img/rabbit.gif")

    l2 =Label(w3,width=200,height=200, bg="yellow", image=None)

    # layout
    l1_29.pack(padx=5, pady=5)
    rb1.pack(padx=5, pady=5)
    rb2.pack(padx=5, pady=5)
    rb3.pack(padx=5, pady=5)
    btnok.pack(padx=5, pady=5)
    l2.pack(padx=5, pady=5)


    w3.mainloop()
