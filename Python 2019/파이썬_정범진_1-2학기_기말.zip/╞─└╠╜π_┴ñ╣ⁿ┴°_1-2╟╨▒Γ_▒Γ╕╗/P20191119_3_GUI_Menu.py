#1119-3.py
#dialog

from tkinter import *
from tkinter.filedialog import *

def P20191119_3() :

    window = Tk()
    window.geometry("400x100")

    label = Label(window,text="file name : ?")
    label.pack()

    filename = askopenfilename(parent=window,
               filetype=(("img 파일","./img/*.gif"),("모든 파일","./img/*.*")))

    label.config(text=str(filename))

    window.mainloop()








