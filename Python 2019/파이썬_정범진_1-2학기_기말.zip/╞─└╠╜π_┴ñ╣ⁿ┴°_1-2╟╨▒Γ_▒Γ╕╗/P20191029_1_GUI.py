#GUI(Graphic User Interface) with tutle grahic. TK
#1029-1.py

from tkinter import *

def P20191029_1() :

    #창 설정
    window = Tk()
    window.title("Gui Test")
    window.geometry("400x400")
    window.resizable(width=FALSE,height=FALSE)
    
    w1=Canvas(window, width=400, height=400)
    w1.pack()

    #텍스트
    L1_1 = Label(w1,text="Welcome to python",font=("휴먼옛체",30),fg="blue",bg="yellow")
    L1_1.pack()

    #사진
    photo1 = PhotoImage(master=w1,file="./img/hart.png") # 확장자 변환X / PNG,GIF 
    L2_1 = Label(w1,image=photo1)
    L2_1.pack()

    #버튼
    btn1_1 = Button(w1,text="push",fg="white",bg="black")
    btn1_1.pack()

    w1.mainloop()

    ###java###
    # import java.awt.*
    # class Win extends Frame
    # Frame f = new Frame()
    # f.setvisible(true)

    # Label label1 = new Label();

    ###java script###
    # windown(?).open("","",width=400, height=400)

