
from tkinter import *

def P20191029_2() :

    def quit() :
        window.destroy()
    
    def myfunc1() :
        print("pushed button1")
    def myfunc2() :
        print("pushed button2")
    def myfunc3() :
        print("pushed button3")

    #창 설정
    window = Tk()
    window.title("Button Test")
    window.geometry("700x300")
    window.resizable(width=FALSE,height=FALSE)

    w2=Canvas(window, width=700, height=300)
    w2.pack()

    #사진
    photo1 = PhotoImage(master=w2,file="./img/eclair.gif")
    photo2 = PhotoImage(master=w2,file="./img/froyo.gif")
    photo3 = PhotoImage(master=w2,file="./img/gingerbread.gif")
    photo1 = photo1.zoom(32)
    photo2 = photo2.zoom(32)


    photo1 = photo1.subsample(32)
    photo2 = photo2.subsample(32)

    button1 = Button(w2,image=photo1,command=myfunc1)
    button2 = Button(w2,image=photo2,command=myfunc2)
    button3 = Button(w2,image=photo3,command=myfunc3)
    exitbutton = Button(window,text="Exit",command=quit)
    exitbutton["padx"]="100"
    exitbutton["pady"]="50"
    exitbutton["font"]="50"
    exitbutton["fg"]="#0000FF"
    exitbutton["bg"]="gray"

    button1.pack(side="left")
    button2.pack(side="left")
    button3.pack(side="left")
    exitbutton.pack(side="left")

    w2.mainloop()

