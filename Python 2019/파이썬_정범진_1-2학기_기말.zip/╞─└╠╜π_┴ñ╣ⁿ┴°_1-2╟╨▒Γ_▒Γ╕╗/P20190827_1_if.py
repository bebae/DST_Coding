
import random

def P20190827_1():
    #if

    a = random.randrange(1,10)
    x = print(f"a : {a}")
    #a = int(x)
    
    b = random.randrange(1,10)
    y = print(f"b : {b}")
    #b = int(y)
   
    
    c = random.randrange(1,10)
    z = print(f"c : {c}")
    #c = int(z)
    

    # if ((a==b)&&(b==c))

    if a == b == c :
        printf("a=b=c")
    elif a == b :
        if a > c :
            print("a = b > c")
        else :
            print("a = b < c")
    elif a == c :
        if a > b :
            print("a = c > b")
        else :
            print("a = c < b")
    elif b == c :
        if a > b :
            print("b = a > c")
        else :
            print("b = c < a")
    elif a < b :
        if b < c :
            print("a < b < c")
        else :
            print("a < c < b")
    elif a < c :
        if a < b :
            print("a < b < c")
        else :
            print("b < a < c")
    elif c < b :
        if a > b :
            print("c < b < a")
        else :
            print("c < a < b")
    elif a > c :
        if c > b :
            print("b < c < a")
        else :
            print("c < b < a")
    else :
        print("오류")

    print("a = ",a)
    print("b = ",b)
    print("c = ",c)
        
    
