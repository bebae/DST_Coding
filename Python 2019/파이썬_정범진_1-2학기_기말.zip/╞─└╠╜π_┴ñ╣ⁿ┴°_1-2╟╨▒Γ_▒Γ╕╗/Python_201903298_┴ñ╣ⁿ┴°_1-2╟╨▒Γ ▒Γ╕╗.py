
from Python_import_all import *

# ──────────────────────────────────── 메뉴 함수
def func_exit() :
    window.quit()
    window.destroy()

    # ──────────────────────── 메뉴바 클릭시 리스트 입력
def func_cal() :
    print("단순 출력")
    # ───── 목록 리스트 초기화
    listbox_log1.delete(0,END)
    # ───── 목록 리스트 입력
    for item in ['P20190827_1','P20190903_1','P20190903_2','P20190903_3','P20190910_2','P20190917_1','P20190917_2',
                 'P20190924_1','P20190924_2']:
        listbox_log1.insert(END,item)
def func_insert() :
    print("입력 필요")
    listbox_log1.delete(0,END)
    for item in ['P20190827_2','P20190910_3','P20191011_1']:
        listbox_log1.insert(END,item)

def func_class() :
    print("클래스 관련")
    listbox_log1.delete(0,END)
    for item in ['P20191001_1','P20191001_2','P20191001_3']:
        listbox_log1.insert(END,item)

        
def func_ui() :
    print("─ GUI ─")
    listbox_log1.delete(0,END)
    for item in ['P20190827_5','P20191029_1','P20191029_2','P20191029_4','P20191029_5','P20191029_6',
                 'P20191105_1','P20191105_2','P20191105_3','P20191112_1','P20191112_2',]:
        listbox_log1.insert(END,item)
def func_ui2() :
    print("─ GUI2 ─")
    listbox_log1.delete(0,END)
    for item in ['P20191119_1','P20191119_2','P20191119_3','P20191119_4']:
        listbox_log1.insert(END,item)
def func_turtle() :
    print("도형")
    listbox_log1.delete(0,END)
    for item in ['P20190827_3','P20190827_4','P20190827_5','P20190827_6']:
        listbox_log1.insert(END,item)

def func_file() :
    print("파일 관련")
    listbox_log1.delete(0,END)
    for item in ['P20191119_5','P20191119_6','P20191119_7']:
        listbox_log1.insert(END,item)

                 
def func_problem() :
    print("과제관련")
    listbox_log1.delete(0,END)
    for item in ['P20190903_4','P20190910_4','P20190917_3','P20190924_3','P20191001_4','P20191011_2',
                 'P20191112_3']:
        listbox_log1.insert(END,item)
def func_test() :
    print("중간고사")
    listbox_log1.delete(0,END)
    for item in ['P20191015_1','P20191022_1']:
        listbox_log1.insert(END,item)

# ──────────────────────────────────── 리스트 버튼 액션
def ListBtn() :
    global btn1
    global btn2
    

    # ────────────────────────────────── 파일 불러오기 함수
    def File(str) :
        # ───── 선언
        infp = None
        inList = ""

        # ───── 파일 열기
        infp = open("./"+str+".py","r",encoding="utf_8")

        # ───── 코드박스 초기화
        listbox_log2.delete(0,END)       

        # ───── 출력
        print ("─────────────────────────────────────")
        while True :
        # ───── 파일에서 한 줄씩 받아오고 공백이면 멈춤
            instr = infp.readline()
            if instr == "" :
                break
            print(instr,end="")             # ───── 콘솔창 출력
            listbox_log2.insert(END,instr)  # ───── 코드박스 출력
        # ───── 파일 닫기
        print ("─────────────────────────────────────")
        infp.close()


    #def ExeBtn() :
        



    # ───── 예외 발생이 많은 부분
    try :

    # ───── 배열의 튜플 위치의 값(문자열)을 text에 저장
        text = listbox_log1.get(listbox_log1.curselection())

        # ───── 파일 이름 날짜 부분 가져오기
        temp_date = text[5:9]
        # ───── 파일 이름의 11번째 문자만 가져와 숫자로 변환
        temp_num = int(text[10:11])

        temp_all = f"P2019{temp_date}_{temp_num}"
        print ("─────────────────────────────────────")
        print("날짜 : "+temp_date)

        if (temp_date == "0827") :
            # ───── 가져온 text에 마지막 문자만 반환해서 숫자로 유사 switch 문1
            if 1 == temp_num :
                File(f"{temp_all}_if")           # ───── 파일 이름
                f_text = P20190827_1             # ───── 파일 실행 할 클래스 이름
            elif 2 == temp_num :
                File(f"{temp_all}_time")
                f_text = P20190827_2
            elif 3 == temp_num :
                File(f"{temp_all}_도형")
                f_text = P20190827_3
            elif 4 == temp_num :
                File(f"{temp_all}_도형")
                f_text = P20190827_4
            elif 5 == temp_num :
                File(f"{temp_all}_도형")
                f_text = P20190827_5
            elif 6 == temp_num :
                File(f"{temp_all}_도형")
                f_text = P20190827_6
            elif 7 == temp_num :
                File(f"{temp_all}_UI")
                f_text = P20190827_7
        elif (temp_date == "0903") :
            if 1 == temp_num :
                File(f"{temp_all}")
                f_text = P20190903_1
            elif 2 == temp_num :
                File(f"{temp_all}")
                f_text = P20190903_2
            elif 3 == temp_num :
                File(f"{temp_all}_for")
                f_text = P20190903_3
            elif 4 == temp_num :
                File(f"{temp_all}_과제")#─────과제
                f_text = P20190903_4
        elif (temp_date == "0910") :       
            if 2 == temp_num :
                File(f"{temp_all}")
                f_text = P20190910_2
            elif 3 == temp_num :
                File(f"{temp_all}_배열")
                f_text = P20190910_3
            elif 4 == temp_num :
                File(f"{temp_all}_과제")#─────과제
                f_text = P20190910_4
        elif (temp_date == "0917") :
            if 1 == temp_num :
                File(f"{temp_all}_배열")
                f_text = P20190917_1
            elif 2 == temp_num :
                File(f"{temp_all}_주사위")
                f_text = P20190917_2
            elif 3 == temp_num :
                File(f"{temp_all}_과제")
                f_text = P20190917_3
        elif (temp_date == "0924") :
            if 1 == temp_num :
                File(f"{temp_all}_목표")
                f_text = P20190924_1
            if 2 == temp_num :
                File(f"{temp_all}_함수")
                f_text = P20190924_2
            if 3 == temp_num :
                File(f"{temp_all}_과제")#─────과제
                f_text = P20190924_3
        elif (temp_date == "1001") :
            if 1 == temp_num :
                File(f"{temp_all}_클래스")
                f_text = P20191001_1
            if 2 == temp_num :
                File(f"{temp_all}_클래스")
                f_text = P20191001_2
            if 3 == temp_num :
                File(f"{temp_all}_클래스")
                f_text = P20191001_3
            if 4 == temp_num :
                File(f"{temp_all}_과제")#─────과제
                f_text = P20191001_4
        elif (temp_date == "1011") :
            if 1 == temp_num :
                File(f"{temp_all}_클래스_5과목")
                f_text = P20191011_1
            if 2 == temp_num :
                File(f"{temp_all}_클래스_과제확인")#─────과제
                f_text = P20191011_2
        elif (temp_date == "1015") :
            if 1 == temp_num :
                File(f"{temp_all}_예비_중간")
                f_text = P20191015_1
        elif (temp_date == "1022") :
            if 1 == temp_num :
                File(f"{temp_all}_중간고사")#─────중간고사
                f_text = P20191022_1
        elif (temp_date == "1029") :
            if 1 == temp_num :
                File(f"{temp_all}_GUI")
                f_text = P20191029_1
            if 2 == temp_num :
                File(f"{temp_all}_GUI")
                f_text = P20191029_2
#            if 3 == temp_num :
#                File(f"{temp_all}_GUI")
#                f_text = P20191029_3
            if 4 == temp_num :
                File(f"{temp_all}_GUI")
                f_text = P20191029_4
            if 5 == temp_num :
                File(f"{temp_all}_GUI")
                f_text = P20191029_5
            if 6 == temp_num :
                File(f"{temp_all}_GUI")
                f_text = P20191029_6
        elif (temp_date == "1105") :
            if 1 == temp_num :
                File(f"{temp_all}_GUI")
                f_text = P20191105_1
            if 2 == temp_num :
                File(f"{temp_all}_GUI")
                f_text = P20191105_2
            if 3 == temp_num :
                File(f"{temp_all}_GUI")
                f_text = P20191105_3
        elif (temp_date == "1112") :
            if 1 == temp_num :
                File(f"{temp_all}_GUI_완성")
                f_text = P20191112_1
            if 2 == temp_num :
                File(f"{temp_all}_GUI_로그인")
                f_text = P20191112_2
            if 3 == temp_num :
                File(f"{temp_all}_GUI_과제")#─────과제
                f_text = P20191112_3
        elif (temp_date == "1119") :
            if 1 == temp_num :
                File(f"{temp_all}_GUI_Menu")
                f_text = P20191119_1
            if 2 == temp_num :
                File(f"{temp_all}_GUI_Menu")
                f_text = P20191119_2
            if 3 == temp_num :
                File(f"{temp_all}_GUI_Menu")
                f_text = P20191119_3
            if 4 == temp_num :
                File(f"{temp_all}_GUI_Menu")
                f_text = P20191119_4
            if 5 == temp_num :
                File(f"{temp_all}_File")
                f_text = P20191119_5
            if 6 == temp_num :
                File(f"{temp_all}_File")
                f_text = P20191119_6
            if 7 == temp_num :
                File(f"{temp_all}_File")
                f_text = P20191119_7

                
    # ───── 예외 발생시 실행
    except :
        print("선택한 값이 없어 실행할 수 없습니다 (목록선택)")
        pass
    
   
    # ────────────────────────────────── 코드 실행 버튼 생성

        # ───── 버튼의 무한적으로 pack 방지
    if (btn2 != None) :
        btn2.pack_forget() # ───── 버튼 제거
        

        
        # ───── 코드박스 밑에 실행버튼
    btn2 = Button(Log_Area2, text='코드실행',padx=150,pady=1)

    try :
        btn2.configure(command=f_text)              # ───── btn2 command 속성 오버라이딩(덮어쓰기)
        btn2.pack(side='bottom')
    except :
        # ───── 예외 발생시 실행
        print("파일을 찾을 수 없어 코드를 실행할 수 없습니니다 (코드실행)")
        


# ─────────────────────────────────────── Main
# ───── 창의 기본구성

window = Tk()
window.title("1학년_2학기_파이썬_기말고사_정범진")
window.geometry("740x650")
window.resizable(width=False,height=False)  # ───── 프레임 크기조절 방지


# ────────────────────────────────────메뉴 붙이기
main_menu = Menu(window)
window.config(menu=main_menu)
# file_menu를 main_menu에 넣는다 / tearoff=0 은 메뉴의 ---- 줄 제거
file_menu = Menu(main_menu,tearoff=0)          


main_menu.add_cascade(label="─파일─",menu=file_menu)   # 추가        
# ────────────────────────────────────menu item

    # ───── 첫번째 메뉴
#file_menu.add_command(label="열기", command=func_open)
file_menu.add_command(label="종료", command=func_exit)

    # ───── 두번째 메뉴
exe_menu = Menu(main_menu,tearoff=0)
main_menu.add_cascade(label="파이썬기초",menu=exe_menu)
exe_menu.add_command(label = "단순 출력", command=func_cal)
exe_menu.add_command(label = "입력 필요", command=func_insert)
exe_menu.add_command(label = "클래스", command=func_class)

    # ───── 세번째 메뉴
ui_menu = Menu(main_menu,tearoff=0)
main_menu.add_cascade(label=" 그래픽 ",menu=ui_menu)
ui_menu.add_command(label = "─ GUI ─", command=func_ui)
ui_menu.add_command(label = "─ GUI2 ─", command=func_ui2)
ui_menu.add_command(label = "터틀그래픽", command=func_turtle)
ui_menu.add_command(label = "파일 관련", command=func_file)

    # ───── 네번째 메뉴
problem_menu = Menu(main_menu,tearoff=0)
main_menu.add_cascade(label="과제모음",menu=problem_menu)
problem_menu.add_command(label = "수업과제", command=func_problem)
problem_menu.add_command(label = "중간고사", command=func_test)

# ──────────────────────────────────── 프레임
frame1=tkinter.Frame(window, relief="solid", bd=2)
frame1.pack(side="left", fill="both", expand=True)

frame2=tkinter.Frame(window, relief="solid", bd=2,width="337")
frame2.pack(side="right", fill="both", expand=True)

# ──────────────────────────────────── 목록박스
    # ───── 목록 테두리 
List_Area1 = LabelFrame(frame1, text="목록", padx=10, pady=10)
List_Area1.place(x=13, y=10)
    # ───── 목록 크기 
List1 = Frame(List_Area1, width=140, height=220, bd=1)
List1.pack()

    # ───── 목록 안 문자 출력 부분
listbox_log1 = Listbox(List1, height=15, width=20, activestyle='none')
listbox_log1.pack(side='left',fill='y')
listbox_log1.grid(row=0,column=0)

    # ──────────────────────────────────── 목록 밑에 버튼 ListBtn
btn2 = None     # ───── 버튼의 무한적으로 pack 방지
btn1 = Button(List1, text='코드보기',padx=45,pady=1, command=ListBtn)
btn1.grid(row=1,column=0,pady=5)

    

# ──────────────────────────────────── 코드박스
    # ───── 코드박스 테두리 
Log_Area2 = LabelFrame(window, text="코드로그", padx=10, pady=10)
Log_Area2.place(x=215, y=10)
    # ───── 코드박스 크기
List2 = Frame(Log_Area2, width=450, height=450, bd=1)
List2.pack()

# ────────────────────────────────────  코드박스 스크롤바
scrollbar = Scrollbar(List2) 
scrollbar.pack(side='right', fill='y')

    # ───── 코드 안 문자 출력 부분 / 스크롤바 연동
listbox_log2 = Listbox(List2, width=66, height=35, activestyle='none',yscrollcommand = scrollbar.set)
scrollbar["command"]=listbox_log2.yview

listbox_log2.pack(side="left")


window.mainloop()

