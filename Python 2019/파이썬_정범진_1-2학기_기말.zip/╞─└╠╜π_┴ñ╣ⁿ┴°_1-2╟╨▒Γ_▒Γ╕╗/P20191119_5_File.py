#1119-8.py
#file

def P20191119_5() :

    # 파일에서 텍스트 읽어오기

    # 선언
    infp = None
    inList = ""


    infp = open("data.txt","r",encoding="utf-8")

    inList = infp.readlines()

    print("───────────────")
    for inStr in inList :
        print(inStr,end="")
    print("")
    print("───────────────")

    infp.close()


