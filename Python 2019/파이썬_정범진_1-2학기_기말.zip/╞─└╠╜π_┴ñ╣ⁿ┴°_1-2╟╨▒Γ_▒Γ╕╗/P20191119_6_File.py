#1119-9.py
#file

def P20191119_6() :

    # 파일에서 텍스트 읽어오기

    # 선언
    infp = None
    inList = ""


    infp = open("P20191119_6_File.py","r",encoding="utf-8")

    while True :
        instr = infp.readline()
        if instr == "" :
            break
        print(instr,end="")

    infp.close()


