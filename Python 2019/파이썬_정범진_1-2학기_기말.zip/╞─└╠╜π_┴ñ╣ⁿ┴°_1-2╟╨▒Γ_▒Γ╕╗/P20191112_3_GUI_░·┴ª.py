#1112-4.py
# WASD
from tkinter import *

# 이미지 위치 초기값
X = 200
Y = 200
# 이미지 크기 확인
img_num = 1

def P20191112_3() :

    #함수 이벤트
    def keyEvent(event) :
        global img_num
        
        photo = PhotoImage(master=w11,file="./img/dog3.gif")
        # chr() : 문자로 변환
        if chr(event.keycode) == "W" :
            photo = PhotoImage(master=w11,file="./img/dog4.gif")
            img_num = 1
        elif chr(event.keycode) == "A" :
            photo = PhotoImage(master=w11,file="./img/cat2.gif")
            img_num = 2
        elif chr(event.keycode) == "D" :
            photo = PhotoImage(master=w11,file="./img/rabbit.gif")
            img_num = 3
        elif chr(event.keycode) == "S" :
            photo = PhotoImage(master=w11,file="./img/dog3.gif")
            img_num = 4

        L1_11.configure(image=photo)
        L1_11.image = photo


    # 과제 부분
    def UpKey(event) :
        global Y
        global img_num
        
        Y -= 20
        # 이미지 큰 것일 경우
        if(img_num == 4) :
            if (Y > -10):
                L1_11.place(x=X,y=Y)
            else :
                Y += 20
        else :
            if(Y > -10):        # 사진이 프레임 밖으로 나가기 방지
                L1_11.place(x=X,y=Y)
            else :
                Y += 20
    def DownKey(event) :
        global Y
        global img_num
        
        Y += 20
        # 이미지 큰 것일 경우
        if(img_num == 4) :
            if (Y < (610-400)):
                L1_11.place(x=X,y=Y)
            else :
                Y -= 20
        else :
            if(Y < (610-200)):
                L1_11.place(x=X,y=Y)
            else :
                Y -= 20
        
    def LeftKey(event) :
        global X
        global img_num
        
        X -= 20
        # 이미지 큰 것일 경우
        if(img_num == 4) :
            if (X > -10):
                L1_11.place(x=X,y=Y)
            else :
                X += 20
        else :
            if(X > -10):
                L1_11.place(x=X,y=Y)
            else :
                X += 20
        
    def RightKey(event) :
        global X
        global img_num
        
        X += 20
        # 이미지 큰 것일 경우
        if(img_num == 4) :
            if (X < (610-400)):
                L1_11.place(x=X,y=Y)
            else :
                X -= 20
        else :
            if(X < (610-200)):
                L1_11.place(x=X,y=Y)
            else :
                X -= 20

    # 창 설정
    window = Tk()
    window.title("방향키 이미지 이동")
    window.geometry("600x600")
    window.resizable(width=False,height=False)  #프레임 크기조절 방지

    w11=Canvas(window,width=600,height=600)
    w11.place(x=0,y=0)



    #텍스트
    L1_2 = Label(w11,text="방향키 이동/WSAD 이미지 변경",font=("휴먼옛체",30),fg="white",bg="black")
    L1_2.place(x=12,y=5)

    # 이미지 라벨
    photo = PhotoImage(master=w11,file="./img/cat2.gif")
    L1_11 = Label(w11,image=photo)

    # 이미지 위치 지정
    L1_11.place(x=X,y=Y)
    #L1_11.pack(expand=1,anchor=CENTER)

    # 이벤트 호출
    window.bind("<Key>",keyEvent)

    # 키보드 설정 (방향키)
    window.bind("<Up>",UpKey)
    window.bind("<Down>",DownKey)
    window.bind("<Left>",LeftKey)
    window.bind("<Right>",RightKey)

    w11.mainloop()
