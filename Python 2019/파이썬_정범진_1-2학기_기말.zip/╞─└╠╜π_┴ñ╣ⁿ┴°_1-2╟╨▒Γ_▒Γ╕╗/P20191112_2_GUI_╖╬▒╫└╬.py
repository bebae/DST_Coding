#1112-5.py
#login UI

from tkinter import *

def P20191112_2() :

    window = Tk()

    w12=Canvas(window)
    w12.pack()

    L1 = Label(w12, text="아이디")
    L1.grid(row=0)
    L2 = Label(w12, text="비밀번호")
    L2.grid(row=1)

    E1 = Entry(w12)     # <input type="text" name="">
    E1.grid(row=0,column=1)
    E2 = Entry(w12)
    E2.grid(row=1,column=1)


    B1 = Button(w12,text="종료",command=quit)
    B1.grid(row=3,column=1,sticky=W,ipadx=50)

    w12.mainloop()
