

def P20191001_2() :
    
    # class car speed
    class Car :

        #field
        name = ""
        color = ""
        speed = 0

        #construction
        def __init__(self, color, name) :
            self.speed = 0
            self.color = color
            self.name = name

        def speedup(self,value) :
            self.speed += value
            if self.speed > 120 :
                self.speed = 120
                print("over 120km")

        def speeddown(self,value) :
            self.speed -= value

        def stop(self) :
            self.speed = 0
            
        def info(self) :
            print("kind : %s / color : %s / speed : %d" %
                  (self.name, self.color, self.speed))



    #main
    avante = Car("white", "avante")
    avante.name = "avante"  # cf java
    avante.color = "white"
    avante.speedup(10)
    avante.speedup(10)
    avante.speeddown(10)
    avante.stop()
    avante.info()
