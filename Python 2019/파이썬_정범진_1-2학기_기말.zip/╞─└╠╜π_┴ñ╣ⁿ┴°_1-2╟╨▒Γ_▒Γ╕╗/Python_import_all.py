import os
import tkinter
import random

from tkinter import *
from tkinter import simpledialog
from tkinter.filedialog import *
from tkinter.simpledialog import*
from tkinter.colorchooser import*

from P20190827_1_if import *
from P20190827_2_time import *
from P20190827_3_도형 import *
from P20190827_4_도형 import *
from P20190827_5_도형 import *
from P20190827_6_도형 import *
from P20190827_7_UI import *

from P20190903_1 import *
from P20190903_2 import *
from P20190903_3_for import *
from P20190903_4_과제 import *

from P20190910_2 import *
from P20190910_3_배열 import *
from P20190910_4_과제 import *

from P20190917_1_배열 import *
from P20190917_2_주사위 import *
from P20190917_3_과제 import *

from P20190924_1_목표 import *
from P20190924_2_함수 import *
from P20190924_3_과제 import *

from P20191001_1_클래스 import *
from P20191001_2_클래스 import *
from P20191001_3_클래스 import *
from P20191001_4_과제 import *

from P20191011_1_클래스_5과목 import *
from P20191011_2_클래스_과제확인 import *

from P20191015_1_예비_중간 import *
from P20191022_1_중간고사 import *

from P20191029_1_GUI import *
from P20191029_2_GUI import *
#from P20191029_3_GUI import *
from P20191029_4_GUI import *
from P20191029_5_GUI import *
from P20191029_6_GUI import *

from P20191105_1_GUI import *
from P20191105_2_GUI import *
from P20191105_3_GUI import *

from P20191112_1_GUI_완성 import *
from P20191112_2_GUI_로그인 import *
from P20191112_3_GUI_과제 import *

from P20191119_1_GUI_Menu import *
from P20191119_2_GUI_Menu import *
from P20191119_3_GUI_Menu import *
from P20191119_4_GUI_Menu import *
from P20191119_5_File import *
from P20191119_6_File import *
from P20191119_7_File import *


