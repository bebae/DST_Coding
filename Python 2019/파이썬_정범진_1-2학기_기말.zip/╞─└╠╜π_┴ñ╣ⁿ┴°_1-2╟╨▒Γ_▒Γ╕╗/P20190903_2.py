# 3 subjects scores
import random

def P20190903_2() :
    
    kor = 90
    eng = random.randrange(0,100)
    mat = random.randrange(80,100)
    print (f"mat : {mat}")

    tot = kor + eng +mat
    ave = tot/3

    if(ave >= 90) :
        grade = "A"
    elif(ave >= 80) :
        grade = "B"
    elif(ave == 70) :
        grade = "C"
    else :
        grade = "F"


    print("kor = %d" % kor)
    print("eng = %d" % eng)
    print("mat = %d" % mat)
    print("tot = %d" % tot)
    print("ave = %d" % ave)
    print("grade = %s" % grade)
