#1105 - 1

# 레이아웃
# java
# class W extends Frame
# Panel p1 = new Panel();
# p1.setLayout(new BorderLaout()) center;
# p1.setLayout(new FlowLaout()) top left;
# GridLayout(2,2);
# Frame f = new Frame();
# f.add(p1);

# app xml UI

from tkinter import *

def P20191105_1() :

    def btn1() :
        print("────────────────버튼 1")
    def btn2() :
        print("────────────────버튼 2")
    def btn3() :
        print("────────────────버튼 3")

    window = Tk()
    window.geometry("300x400")

    w7=Canvas(window, width=300, height=400)
    w7.pack()

    button1 = Button(w7,text="버튼 1",bg="yellow",command=btn1)
    button1["fg"] = "blue"
    button2 = Button(w7,text="버튼 2",font=("돋움체",20),command=btn2)
    button3 = Button(w7,text="버튼 3")

    photo1 = PhotoImage(master=w7,file="./img/dog.png")

    button4 = Button(w7,image=photo1,command=btn3)

    button1.pack()
    button1.place(x=0,y=0)
    button2.place(x=100,y=100)
    button3.place(x=200,y=200)
    button4.place(x=0,y=200)    

    w7.mainloop()
