import tkinter

window=tkinter.Tk()
window.title("YUN DAE HEE")
window.geometry("640x400+100+100")
window.resizable(False, False)

frame=tkinter.Frame(window)
frame.pack()

scrollbar=tkinter.Scrollbar(frame)
scrollbar.pack(side="right", fill="y")

listbox=tkinter.Listbox(frame, yscrollcommand = scrollbar.set)
scrollbar["command"]=listbox.yview

for line in range(1,1001):
   listbox.insert(line, str(line) + "/1000")
listbox.pack(side="left")





window.mainloop()
