#1029-4.py

from tkinter import *
import tkinter.messagebox

def P20191029_4() :

    def myfunc() :
        tkinter.messagebox.showinfo("강아지 버튼","강아쥐 귀엽지")
        
    def quit() :
            window.destroy()
            
    window = Tk()
    window.geometry("300x300")
    window.title("pic pushed event")
    window.resizable(width= FALSE,height=FALSE)

    w4=Canvas(window, width=300, height=300)
    w4.pack()


    photo = PhotoImage(master=w4,file="./img/dog4.gif")
    btn = Button(w4,image=photo, command=myfunc)
    exitbutton = Button(w4,text="Exit",width=28,height=5,bg="green",command=quit)
    btn.pack()
    exitbutton.pack()

    w4.mainloop()
