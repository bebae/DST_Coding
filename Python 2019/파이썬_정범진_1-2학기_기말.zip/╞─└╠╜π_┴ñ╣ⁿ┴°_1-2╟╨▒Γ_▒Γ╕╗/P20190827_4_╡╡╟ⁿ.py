#0827-7.py
# graphic tutle, tk....

import turtle as t

def P20190827_4() :
    
    # 삼각형
    t.color("red") #ff0000

    t.forward(100) #100 pixel
    t.left(120)    # angle
    t.forward(100) #100 pixel
    t.left(120)    # angle
    t.forward(100) #100 pixel
    t.left(120)    # angle

    #사각형
    t.color("blue")
    t.pensize(3)  # width
    t.forward(100) #100 pixel
    t.left(90)    # angle
    t.forward(100) #100 pixel
    t.left(90)    # angle
    t.forward(100) #100 pixel
    t.left(90)    # angle
    t.forward(100) #100 pixel
    t.left(90)    # angle

    # 원
    t.color("green")
    t.pensize(2)
    t.circle(100)



