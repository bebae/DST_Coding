# two integer
import random

def P20190903_1() :
    
    x = 20
    y = 10
    result = x+y

    print(result)
    print("%d + %d = %d" % (x,y,result))

    if (x > y) :
        print("%d가 %d보다 크다" % (x,y))
    elif(x==y) :
        print("%d가 %d와 같다" % (x,y))
    else :
        print("%d가 %d와 같다" % (y,x))

        
    # x = (int)(Math.random()*20);

    x = random.randrange(0,20)
    y = random.randrange(0,10)

    result = x+y

    print(result)
    print("%d + %d = %d" % (x,y,result))

    x = random.randrange(0,20)
    y = random.randrange(0,10)

    print(f"x : {x}")
    print(f"y : {y}")

    result = x+y

    print("결과값 : " ,end="")
    print(result)


