# graphio uset interface
from tkinter import *
from time import *

def P20190827_7() :

    window = Tk()
    window.title("gul test")
    window.geometry("400x300")
    
    w=Canvas(window, width=400, height=400)
    w.pack()

    l1 = Label(w,text="강아지",font=("굴림",30),fg="blue",bg="yellow")
    l1.pack()

    # 이미지
    photo = PhotoImage(master=w,file="./img/dog.png")
    l2 = Label(w, image=photo)
    l2.pack() #윈도우 창에 붙이기

    b1 = Button(w,text="Push",fg="blue",bg="yellow")
    b1.pack()

    w.mainloop()
