#1105-5.py event process btn click event발생 ->처리
#                                  interrupt
from tkinter import *
import tkinter.messagebox

def P20191105_3() :

    btnList = [""]*9
    fnameList=["eclair.gif","froyo.gif","gingerbread.gif","honeycomb.gif",
               "icecream.gif", "jellybean.gif","kitkat.gif","lollipop.gif",
               "marshmallow.gif"]
    photoList=[None]*9
    i,k=0,0  #loop var
    num=0    # 9개 posi
    xpos, ypos = 0,0 # matrix pos  1,1 3,3

    # event handler
    def clickImage(event,i) :
        print("btn clicked %d"% i )
        tkinter.messagebox.showinfo("imade btn","%d btn clicked" % i)
        
    window = Tk()
    window.geometry("210x210")

    w9=Canvas(window, width=210, height=210)
    w9.pack()


    # button gene.
    for i in range(0,9) :
        photoList[i] = PhotoImage(master=w9,file="./img/" + fnameList[i])
        btnList[i] = Button(w9,image=photoList[i])


    #layout - grid  matrix 3x3
    for i in range(0,3) : #0, 1
        btnList[num].grid(row=i)
        for k in range(0,3) :
            btnList[num].grid(row=i,column=k)
            num += 1
    #java listner,monitor
    # btn.addLisnter(this)
    #for i in range(0,9) :
        btnList[0].bind("<Button>",lambda event : clickImage(event,0))
        btnList[1].bind("<Button>",lambda event : clickImage(event,1))
        btnList[2].bind("<Button>",lambda event : clickImage(event,2))
        btnList[3].bind("<Button>",lambda event : clickImage(event,3))
        btnList[4].bind("<Button>",lambda event : clickImage(event,4))
        btnList[5].bind("<Button>",lambda event : clickImage(event,5))
        btnList[6].bind("<Button>",lambda event : clickImage(event,6))
        btnList[7].bind("<Button>",lambda event : clickImage(event,7))
        btnList[8].bind("<Button>",lambda event : clickImage(event,8))
        
    w9.mainloop()

