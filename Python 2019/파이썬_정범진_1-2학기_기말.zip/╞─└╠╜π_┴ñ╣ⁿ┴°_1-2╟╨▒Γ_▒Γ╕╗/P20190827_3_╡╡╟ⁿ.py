# 삼각형

import turtle as t

def P20190827_3() :
    t.speed(10)

    # 삼각형
    t.color("red")  #ff0000
    t.pensize(3)

    t.forward(200)  #100 pixel
    t.left(120)     # angle
    t.forward(200)
    t.left(120)
    t.forward(200)
    t.left(120)

    # 사각형
    t.color("blue") 
    t.pensize(3)    # width
    
    t.forward(200)  #100 pixel
    t.left(90)      # angle
    t.forward(200)
    t.left(90)
    t.forward(200)
    t.left(90)
    t.forward(200)
    t.left(90)

    # 육각형
    t.color("green") 
    t.pensize(3)    # width

    t.forward(200)  #100 pixel
    t.left(60)      # angle
    t.forward(200)
    t.left(60)
    t.forward(200)
    t.left(60)
    t.forward(200)
    t.left(60)
    t.forward(200)
    t.left(60)
    t.forward(200)
    t.left(60)

