
def P20190903_3() :
    hap = 0
    count = 0
    x = 1
    y = 10
    for i in range(x,y) :
        hap += i
        count += 1

    print("x = %d" % x)
    print("y = %d" % y)
    print("hap = %d" % hap)
    print("ave = %d" % (hap/count))
